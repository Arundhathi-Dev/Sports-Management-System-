module.exports = function(app){

app.get('/public/index_files/LineIcons.css', function(req, res) {
  res.sendFile(__dirname + "/" + "/public/index_files/LineIcons.css");
});

app.get('/public/index_files/f-shape-1.svg', function(req, res) {
  res.sendFile(__dirname + "/" + "/public/index_files/f-shape-1.svg");
});


app.get('/public/index_files/bootstrap.min.css', function(req, res) {
  res.sendFile(__dirname + "/" + "/public/index_files/bootstrap.min.css");
});


app.get('/public/index_files/default.css', function(req, res) {
  res.sendFile(__dirname + "/" + "/public/index_files/default.css");
});

app.get('/public/index_files/style.css', function(req, res) {
  res.sendFile(__dirname + "/" + "/public/index_files/style.css");
});

//
app.get('/public/index_files/LineIcons.css', function(req, res) {
  res.sendFile(__dirname + "/" + "admin/index_files/jquery-1.12.4.min.js.download");
});

app.get('/public/index_files/f-shape-1.svg', function(req, res) {
  res.sendFile(__dirname + "/" + "/public/index_files/f-shape-1.svg");
});


app.get('/public/index_files/bootstrap.min.css', function(req, res) {
  res.sendFile(__dirname + "/" + "/public/index_files/bootstrap.min.css");
});


app.get('/public/index_files/default.css', function(req, res) {
  res.sendFile(__dirname + "/" + "/public/index_files/default.css");
});

app.get('/public/index_files/style.css', function(req, res) {
  res.sendFile(__dirname + "/" + "/public/index_files/style.css");
});


//
app.get('/public/index_files/LineIcons.css', function(req, res) {
  res.sendFile(__dirname + "/" + "/public/index_files/LineIcons.css");
});

app.get('/public/index_files/f-shape-1.svg', function(req, res) {
  res.sendFile(__dirname + "/" + "/public/index_files/f-shape-1.svg");
});


app.get('/public/index_files/bootstrap.min.css', function(req, res) {
  res.sendFile(__dirname + "/" + "/public/index_files/bootstrap.min.css");
});


app.get('/public/index_files/default.css', function(req, res) {
  res.sendFile(__dirname + "/" + "/public/index_files/default.css");
});

app.get('/public/index_files/style.css', function(req, res) {
  res.sendFile(__dirname + "/" + "/public/index_files/style.css");
});
}