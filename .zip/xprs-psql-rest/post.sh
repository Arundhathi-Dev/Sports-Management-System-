curl -d '{"teamName": "Unknowns", "originCountry": "India", "gameId": 1}' -H "Content-Type: application/json" -X POST http://localhost:3000/api/admin/register_team
